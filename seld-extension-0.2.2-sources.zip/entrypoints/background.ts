import { defineBackground } from 'wxt/sandbox';
import { browser } from 'wxt/browser';

export default defineBackground(() => {
    // Open welcome page on install or update
    browser.runtime.onInstalled.addListener(({ reason }) => {
        if (reason === 'install' || reason === 'update') {
            browser.tabs.create({
                url: chrome.runtime.getURL('/extension-pages/welcome.html'),
            });
        }
    });

    const isRestrictedPage = (url?: string): boolean => {
        if (!url) return true;
        const restrictedPrefixes = [
            'chrome://',
            'chrome-extension://',
            'about:',
            'edge://',
            'moz-extension://',
            'https://chrome.google.com/webstore',
            'https://addons.mozilla.org/'
        ];
        return restrictedPrefixes.some(prefix => url.startsWith(prefix));
    };

    const handleSidebarToggle = async (tabId?: number, url?: string) => {
        if (isRestrictedPage(url)) {
            browser.notifications.create({
                type: 'basic',
                iconUrl: browser.runtime.getURL('/icon-128.png'),
                title: 'Action Restricted',
                message: 'SELD Dictionary Sidebar cannot be opened on restricted browser pages.',
            });
            return;
        }

        if (tabId) {
            try {
                await browser.tabs.sendMessage(tabId, { action: 'TOGGLE_SIDEBAR' });
            } catch (e) {
                console.error("[SELD] Error sending TOGGLE_SIDEBAR from background:", e);
            }
        }
    };

    // Listen for messages from the content script (keeping existing for now if needed, but cleaning up sidePanel)
    browser.runtime.onMessage.addListener((message: any, sender, sendResponse) => {
        if (message.action === 'GET_TTS_AUDIO') {
            const { text, tl } = message;
            const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=${tl || 'si'}&client=tw-ob`;

            fetch(url)
                .then(response => {
                    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
                    return response.arrayBuffer();
                })
                .then(buffer => {
                    // Convert ArrayBuffer to Base64
                    const base64 = btoa(
                        new Uint8Array(buffer)
                            .reduce((data, byte) => data + String.fromCharCode(byte), '')
                    );
                    sendResponse({ audioData: base64 });
                })
                .catch(error => {
                    console.error("[SELD] TTS fetch error:", error);
                    sendResponse({ error: error.message });
                });
            return true; // Keep message channel open for async response
        } else if (message.action === 'REQUEST_TOGGLE_SIDEBAR') {
            browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
                const tab = tabs[0];
                handleSidebarToggle(tab?.id, tab?.url);
            });
            sendResponse({ success: true });
        }
        return true;
    });
});


